#pragma once

/* Copy/rename to app_local.h and customize.  In-place updates preserve app_local.h. */
#define PERSON_1_NAME "Adult 1"
#define PERSON_2_NAME "Adult 2"
#define PERSON_3_NAME "Family"
#define PERSON_4_NAME "Other"

#define HA_CALENDAR_1 "calendar.person_1"
#define HA_CALENDAR_2 "calendar.person_2"
#define HA_CALENDAR_3 "calendar.family"
#define HA_CALENDAR_4 ""

/*
 * Optional: preselect a Home Assistant To-do list for the Chores dashboard.
 * Leave blank to choose an available todo.* entity directly on the touchscreen.
 */
#define HA_CHORE_TODO_ENTITY ""

/* Optional: preselect an Alarmo alarm_control_panel entity.
 * Leave blank to choose an available Alarmo panel on the touchscreen. */
#define HA_ALARMO_ENTITY ""

/*
 * Optional: preselect a Home Assistant binary_sensor for wake-on-approach.
 * Good choices are a camera person-detection, motion, occupancy, or presence
 * binary sensor. Leave blank to choose one from the Settings screen.
 */
#define HA_WAKE_PRESENCE_ENTITY ""

/*
 * Optional default screen timeout in seconds. Supported Settings choices are
 * Off (0), 30, 60, 120, 300, and 600 seconds. The on-screen choice persists.
 */
#define APP_SCREEN_TIMEOUT_SECONDS 120U

/* Legacy/local chore labels retained for compatibility. */
#define CHORE_1_NAME "Feed pets"
#define CHORE_2_NAME "Dishwasher"
#define CHORE_3_NAME "Trash / recycling"
#define CHORE_4_NAME "Tidy kitchen"
#define CHORE_5_NAME "Laundry"
#define CHORE_6_NAME "Mail / packages"

/* Optional active-tab auto-refresh overrides (milliseconds).
 * Uncomment only if you want different refresh cadences.
 */
// #define HA_ACTIVE_TAB_CALENDAR_REFRESH_MS 300000UL
// #define HA_ACTIVE_TAB_CHORES_REFRESH_MS 60000UL
// #define HA_ACTIVE_TAB_ALARM_REFRESH_MS 15000UL
